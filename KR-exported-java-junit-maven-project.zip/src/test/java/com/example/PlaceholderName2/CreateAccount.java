package com.example.PlaceholderName2;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.apache.commons.io.FileUtils;
import java.io.File;

public class CreateAccount {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  JavascriptExecutor js;
  @Before
  public void setUp() throws Exception {
    System.setProperty("webdriver.chrome.driver", "");
    driver = new ChromeDriver();
    baseUrl = "https://www.google.com/";
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
    js = (JavascriptExecutor) driver;
  }

  @Test
  public void testCreateAccount() throws Exception {
    driver.get("http://localhost:8080/term-project-placeholder-name-2/Home.jsp");
    //ERROR: Caught exception [Error: locator strategy either id or name must be specified explicitly.]
    driver.get("http://localhost:8080/term-project-placeholder-name-2/CheckoutPage.jsp");
    driver.findElement(By.xpath("//input[@value='Logout']")).click();
    driver.get("http://localhost:8080/term-project-placeholder-name-2/login.html");
    driver.findElement(By.name("user")).click();
    driver.findElement(By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Placeholder Laundromat'])[1]/following::p[1]")).click();
    driver.findElement(By.linkText("here")).click();
    driver.get("http://localhost:8080/term-project-placeholder-name-2/signup.html");
    driver.findElement(By.name("usr")).click();
    driver.findElement(By.name("usr")).clear();
    driver.findElement(By.name("usr")).sendKeys("TestUserNam");
    driver.findElement(By.name("usr")).click();
    driver.findElement(By.name("usr")).clear();
    driver.findElement(By.name("usr")).sendKeys("TestUserName");
    driver.findElement(By.name("pwd")).click();
    driver.findElement(By.name("pwd")).clear();
    driver.findElement(By.name("pwd")).sendKeys("TestPassword");
    driver.findElement(By.name("fname")).clear();
    driver.findElement(By.name("fname")).sendKeys("TestFirst");
    driver.findElement(By.name("lname")).clear();
    driver.findElement(By.name("lname")).sendKeys("TestLast");
    driver.findElement(By.name("phone")).clear();
    driver.findElement(By.name("phone")).sendKeys("0000000000");
    driver.findElement(By.name("mail")).click();
    driver.findElement(By.name("mail")).clear();
    driver.findElement(By.name("mail")).sendKeys("test@test.com");
    driver.findElement(By.xpath("//input[@value='Submit']")).click();
    driver.get("http://localhost:8080/term-project-placeholder-name-2/login_signup.html");
    driver.findElement(By.name("user")).click();
    driver.findElement(By.name("user")).clear();
    driver.findElement(By.name("user")).sendKeys("test");
    driver.findElement(By.name("user")).click();
    driver.findElement(By.name("user")).click();
    //ERROR: Caught exception [ERROR: Unsupported command [doubleClick | name=user | ]]
    driver.findElement(By.name("user")).click();
    driver.findElement(By.name("user")).clear();
    driver.findElement(By.name("user")).sendKeys("TestUsername");
    driver.findElement(By.name("pwd")).click();
    driver.findElement(By.name("pwd")).clear();
    driver.findElement(By.name("pwd")).sendKeys("TestPassword");
    driver.findElement(By.name("user")).click();
    driver.findElement(By.name("user")).clear();
    driver.findElement(By.name("user")).sendKeys("TestUserName");
    driver.findElement(By.xpath("//input[@value='Login']")).click();
    driver.get("http://localhost:8080/term-project-placeholder-name-2/Home.jsp");
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
