package tables;

public class Machine 
{
	private int machine_id;
	private String makemodel;
	private int runtime;
	
	public int getMachineID() 
	{
		return machine_id;
	}
	
	public String getMakemodel() 
	{
		return makemodel;
	}

	public int getRuntime() 
	{
		return runtime;
	}

}
