package tables;

import java.time.LocalDateTime;

public class Reservation 
{
	private int machine_id;
	private String username;
	private LocalDateTime start_time;
	private LocalDateTime end_time;
	
	public Reservation(int machine_id, String username, LocalDateTime start_time, LocalDateTime end_time) 
	{
		super();
		this.machine_id = machine_id;
		this.username = username;
		this.start_time = start_time;
		this.end_time = end_time;
	}
	
	public int getMachineID() 
	{
		return machine_id;
	}

	public void setMachineID(int machine_id) 
	{
		this.machine_id = machine_id;
	}

	public String getUsername() 
	{
		return username;
	}

	public void setUsername(String username) 
	{
		this.username = username;
	}

	public LocalDateTime getStartTime() 
	{
		return start_time;
	}

	public void setStartTime(LocalDateTime start_time) 
	{
		this.start_time = start_time;
	}

	public LocalDateTime getEndTime() 
	{
		return end_time;
	}

	public void setEndTime(LocalDateTime end_time) 
	{
		this.end_time = end_time;
	}



	
	
}
